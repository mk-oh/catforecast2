library(testthat)
library(catforecast2)

test_check("catforecast2")
